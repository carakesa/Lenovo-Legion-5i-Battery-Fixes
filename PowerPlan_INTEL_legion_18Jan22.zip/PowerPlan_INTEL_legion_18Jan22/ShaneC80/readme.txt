Originally stolen^H^H^H^H^H from the LegionPowerPlan zip found on the Lenovo Forums.

ShaneC80's edits are taken in part from u/AyyounAli on here:

https://www.reddit.com/r/LenovoLegion/comments/s4o6ke/battery_drain_issue_on_legion_7i_2021_solved/

and uses:  powercfg.exe -attributes SUB_PROCESSOR PERFBOOSTMODE -ATTRIB_HIDE

to change the preformace boost modes (battery) for "Balanced" and "Quiet" to something less aggressive.

Integrates with Lenovo Legion Toolkit from:   https://github.com/BartoszCichecki/LenovoLegionToolkit

Using Tools > More Settings you can assign the power profiles to switch with the FN+Q toggle.